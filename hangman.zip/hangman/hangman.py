import random

def hangman():

    lifes = 20
    name = None

    name = input("Enter your name: ")

    print(f"Lets play {name}, you have '{lifes}' lifes to win.")


    data = open("secretwords.txt","r")
    words = data.readlines()

    words = [word.strip("\n") for word in words ]

    secret_word =  words[random.randrange(len(words))]
    
    guess_word = ['-' for count in range(len(secret_word))]

    temp_word = "".join(guess_word)
    print(f"\nGuess the word: {temp_word}")

    index = 0

    while True:

        save = input("\nEnter 1 character: ")

        flag = True

        if len(save) == 1:

            for count in range(len(secret_word)):

                if secret_word[count].lower() == save.lower() and guess_word[count] == '-':

                    for count2 in range(count,len(secret_word)):

                        if secret_word[count2].lower() == save.lower():

                            index += 1

                            flag = False

                            guess_word[count2] = save.lower()

                    temp_word = "".join(guess_word)

                    print(f"\ncorrect!  {temp_word}")
                    print(f"lifes left {lifes}")
                                        
                    if index == len(secret_word):
                        print("\nYou win !")
                        return 
                    
                
                elif count + 1 == len(guess_word) and flag:

                    print("\n ooh you are wrong!")

                    lifes -= 1

                    print(f"lifes left {lifes}")

                if lifes == 0:
                    print("\nYou lose!")
                    print(f"Correct word was {secret_word}")       
                    return 


if __name__ == "__main__":

    hangman()
    
    while True:

        inputt = input("\n Want to play again ? (y/n): ")

        if inputt == "y":
            hangman()
        elif inputt == "n":
            print("\n See you next time :)")
            break